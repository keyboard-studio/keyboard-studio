# Test Autonym

Welcome to the keyboard.

## Links
- Online help: https://help.keyman.com/keyboard/test

## Supported Platforms
- any
