# Test Autonym

Welcome to the keyboard.

For typing Test (Test Autonym, `fr`) in the Latin script. Based on French Basic (AZERTY layout).

## Characters

- Letters: µ À Â Ã Ä È Ê Ë Ì Î Ï Ñ Ò Ô Õ Ö Ù Û Ü à â ã ä ç è é ê ë ì î ï ñ ò ô õ ö ù û ü ÿ
- Punctuation and symbols: £ ¤ § ¨ ° €
- Digits: ²
- Removed from French Basic: µ Ã Ä Ì Ñ Ò Õ Ö ã ä ì ñ ò õ ö

Accented letters are produced as single characters.

## How to type

| Keys | Gives |
|------|-------|
| Shift + \] | £ |
| AltGr + \] | ¤ |
| Shift + / | § |
| Shift + \[ then Space | ¨ |
| Shift + - | ° |
| \` | ² |
| Shift + \\ | µ |
| long-press " (touch) | “ |

Full guide with every key: see the welcome page.

## Fonts

Some of these characters need a font that supports them. Without one they may show as empty boxes.

## Tips

- Press a key to start.

## Design notes

- Started from French Basic.
- Letters: key sequences. Punctuation and symbols: Right Alt, key sequences, touch long-press or flick.
- The touch layout was adapted from French Basic.
- 15 characters of French Basic were removed; those keys now do nothing.

## Links
- Online help: https://help.keyman.com/keyboard/test
- Keyman keyboards page: https://keyman.com/keyboards/test

## Supported Platforms
- any
