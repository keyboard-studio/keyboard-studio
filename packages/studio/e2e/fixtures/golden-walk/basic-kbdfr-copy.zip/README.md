# Test Autonym

Welcome to the keyboard.

For typing Test (Test Autonym, `fr`) in the Latin script. Based on French Basic (AZERTY layout).

## Characters

- Letters: À Â Æ È Ê Ë Î Ï Ô Ù Û Ü à â æ ç è é ê ë î ï ô ù û ü ÿ Œ œ
- Marks: ◌̀ ◌́ ◌̂ ◌̈ ◌̧
- Punctuation and symbols: £ ¤ § ¨ « ° » ‐ ‑ – — ’ “ ” † ‡ … €
- Numbers: ²
- Removed from French Basic: µ Ã Ä Ì Ñ Ò Õ Ö ã ä ì ñ ò õ ö

Accented letters are produced as a letter followed by a combining mark.

## How to type

| Keys | Gives |
|------|-------|
| 0 | à |
| \[ then a | â |
| z then z then q then e then 6 then j | æ |
| 9 | ç |
| 7 | è |
| 2 | é |
| AltGr + \] | ¤ |
| long-press " (touch) | “ |

Full guide with every key: see the welcome page.

## Fonts

Some of these characters need a font that supports them. Without one they may show as empty boxes.

## Tips

- Press a key to start.

## Design notes

- Started from French Basic.
- Letters: key sequences. Marks: key sequences. Punctuation and symbols: Right Alt, key sequences, touch long-press or flick.
- The touch layout was adapted from French Basic.
- 15 characters of French Basic were removed; those keys now do nothing.

## Links
- Online help: https://help.keyman.com/keyboard/test
- Keyman keyboards page: https://keyman.com/keyboards/test

## Supported Platforms
- any
