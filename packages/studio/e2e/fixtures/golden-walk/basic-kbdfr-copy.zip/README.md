# Test Autonym

Welcome to the keyboard.

## Links
- Online help: https://help.keyman.com/keyboard/test
- Keyman keyboards page: https://keyman.com/keyboards/test

## Supported Platforms
- any
