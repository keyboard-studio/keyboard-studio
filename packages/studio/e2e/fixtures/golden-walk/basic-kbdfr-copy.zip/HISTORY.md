## 1.0 (2026-10-28)
* Created from basic_kbdfr v1.1 via keyboard-studio.
* Added 28 characters: a, A, e, E, u, U, a, A, e, E, and 18 more.
* Assigned mechanisms: ‐, ‑, –, —, …, ’, “, ”, «, », and 2 more.
