## 1.0 (2026-11-11)
* Created from basic_kbdfr v1.1 via keyboard-studio.
* Added 21 characters: ‐, ‑, –, —, …, ’, “, ”, «, », and 11 more.
* Removed 15 characters.
