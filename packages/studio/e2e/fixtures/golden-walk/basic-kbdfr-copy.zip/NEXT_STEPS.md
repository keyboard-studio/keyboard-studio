# Next Steps

Your keyboard has been packaged and is ready to submit to the Keyman keyboard repository.

## Option A — Submit via GitHub (recommended)

1. Fork `keyboard-studio/keyboards` at https://github.com/keyboard-studio/keyboards
2. Create a branch: `git checkout -b add/<your-keyboard-id>`
3. Copy the keyboard files into `release/<first-letter>/<your-keyboard-id>/`.
   Do not copy `NEXT_STEPS.md` or the `.studio/` folder — see "Studio metadata" below.
   Leave out two more folders if the zip has them:
   - `build/` holds compiled files. The repository builds its own, and a pull
     request must not contain compiled output.
   - `shared/` holds fonts the package uses. They belong in the repository's
     top-level `shared/` folder, which is where the `.kps` file looks for them
     (`..\..\..\shared\…`). Most are already there; add only a font that is missing.
4. Commit and push your branch
5. Open a pull request from your fork to `keyboard-studio/keyboards:master`

## Option B — Email submission

Email the zip archive to keymanhelp@sil.org with the subject:
"New keyboard submission: <your-keyboard-id>"

## Studio metadata (not part of the keyboard)

This file and everything under `.studio/` were added by keyboard-studio
for you, not for the keyboard repository. Do not copy them into
`release/<first-letter>/<your-keyboard-id>/` — the keyboard's directory should look
exactly as it would if you had written it by hand.

- `.studio/decision-record.json` — the record of the decisions you made while
  authoring, and what each one changed in the source. Useful for picking the work
  up again later, or for answering a reviewer's question about why something is
  the way it is.

## Resources

- Keyman keyboard contribution guide: https://help.keyman.com/developer/keyboards/
- keyboard-studio documentation: https://github.com/keyboard-studio/keyboard-studio
