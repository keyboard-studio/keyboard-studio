<?php
$pagename = 'Cameroon QWERTY Keyboard Help';
$pagetitle = 'Cameroon QWERTY (SIL) Keyboard Help';
require_once('header.php');
?>

<head>
<meta charset="utf-8">
<title>Cameroon QWERTY Keyboard Help</title>
<meta content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0" name="viewport" />
<link rel="stylesheet" href="kb.css" />
<link rel="icon" href="Cameroon.ico" />
</head>
<body>
<div class="tab-folder">
<!--Starting English-->
<div id="en" class="tab-content">
<a class="buttonlang" href="#fr"> Cliquer ici pour voir cette page en français...</a>
<div id="container">
<img src="ic_launcher.png" class="left" height="75" />
<img class="right" src="sil-logo-blue.png" height="75" />
<h1 class="color" xml:lang="en">Cameroon <span class="qw">QWERTY</span> Keyboard <span class="keyman"> for Keyman</span>
<br />by SIL Cameroon
</h1>
<p class="tagline" xml:lang="en">Enabling you to type in your mother tongue!</p>
<p xml:lang="en">Welcome to the <span title="A virtual keyboard allowing one to type in the indigenous languages of Cameroon">
<strong>Cameroon <span class="qw">QWERTY</span> Keyboard</strong>
</span> for Keyman. This page will explain how to type in the vernacular languages of Cameroon using the Cameroon <span class="qw">QWERTY</span> Keyboard. </p>
<p xml:lang="en">The <strong>Cameroon <span class="qw">QWERTY</span>
</strong> Keyboard, one of a set of <b>virtual keyboards</b> maintained by the Language Technology team of <a href="https://silcam.org/">SIL Cameroon</a>, allows you to type any languages that follow the <a href="https://langtechcameroon.info/gacl/">General Alphabet of Cameroonian Languages</a>. The Ethnologue lists 279 living languages in Cameroon, and 275 of these are indigenous. For a list of these languages, view
<a href="https://www.ethnologue.com/country/CM/">Cameroon in the Ethnologue</a>.
</p>
<hr />
<p xml:lang="en">To take advantage of the unique features of each device, the Cameroon <span class="qw">QWERTY</span> Keyboard behaves differently on physical keyboards and touch screens, please choose your interface below:</p>
<!--Physical Keyboard-->

<h2 class="color">Physical Keyboard (Windows, Mac, Linux, also Android and iOS with external keyboards) </h2>
<p xml:lang="en">This section covers use of the Cameroon <span class="qw">QWERTY</span> with a physical keyboard, harnessing the power of multiple fingers to type more easily.</p>
<h3 class="color" xml:lang="en">Layout Overview</h3>
<p xml:lang="en">Below is the layout of the Cameroon <span class="qw">QWERTY</span> Keyboard. Once you have learned to use the <span class="keycap">CAM</span> key and <span class="keycap">Shift</span> keys, this image can be used as a quick reference to find available characters.</p>
<img src="QwertyColor.png" class="full qw" />
<h3 class="color" xml:lang="en">Combinations</h3>
<img class="center" src="e_chart.png" xml:lang="en" />
<p xml:lang="en">As shown above, each key on the Cameroon Keyboard can be used to produce multiple characters (letters).</p>
<ol style="list-style-type:decimal; ">
<li xml:lang="en">If you tap the <span class="keycap">E</span> key once, you will get a lowercase
"e".<br />Sometimes you may need to use two keys to get the letter you want. The SHIFT key is a key on a computer keyboard. It is used to type capital letters (like this: "ABC") instead of lowercase ("abc"). </li>
<li xml:lang="en">If you hold the <span class="keycap">Shift</span> key and tap the <span class="keycap">E</span> key once, you will get a capital "E".<br />The Cameroon Keyboard is special, and it is possible to type other Characters not printed on your keyboard using the "CAM" (Cameroon) key. On your Cameroon <span class="qw">QWERTY</span> Keyboard, the CAM key is the <span class="qw">semicolon</span> key (<span class="keycap qw">;</span>). Each time you need the CAM key, just press <span class="keycap qw">;</span>. To get the special characters shown on the right side of each key in the chart (like this: "əɔɓ ") instead of common characters (like "eob"), you need to use the CAM key. </li>
<li xml:lang="en">If you tap the <span class="keycap qw">;</span> key once, and then press the <span class="keycap">E</span> key, you will get schwa "ə". </li>
<li xml:lang="en">If you tap the <span class="keycap qw">;</span> key once, then hold <span class="keycap">Shift</span> and type <span class="keycap">E</span>, you will get capital schwa “Ə”.
<br />In review, if you look at the keyboard chart, you'll see that most keys on the Cameroon keyboard can be used to produce up to four different characters in this way. Use the chart to find the letters you need for your language, and use a combination of <span class="keycap">Shift</span> and the CAM Key (<span class="keycap qw">;</span>) to type them.
</li>
<li xml:lang="en">Unlike French, Cameroonian diacritics (accents) are typed after the letter. For example, you would type: <span class="keycap qw">;</span>
<span class="keycap">e</span>
<span class="keycap qw">'</span> to get "ə̀"
</li>
</ol>
<h3 class="color" xml:lang="en">Specific Keyboard Combination Details:</h3>
<p xml:lang="en">Computers bought in different countries tend to have different <strong>physical keyboard layouts</strong>. When using <strong>virtual keyboards</strong>, it is MUCH easier to learn the keyboard if the keys are <strong>in the same place</strong> as the letters you want to type.</p>
<p xml:lang="en">The Cameroon <span class="qw">QWERTY</span> keyboard is designed for computers with the following physical keyboards:</p>
<ul xml:lang="en" class="qw">
<li>US English (QWERTY): <a href="qwerty-us-en.php">See all combinations.</a></li>
<li>UK Engish (QWERTY): <a href="qwerty-uk-en.php">See all combinations.</a></li>
<li>Swiss French (QWERTZ): <a href="qwerty-ch-en.php">See all combinations.</a></li>
<li>German (QWERTZ): <a href="qwerty-de-en.php">See all combinations.</a></li>
</ul>
<blockquote xml:lang="en">Note: If your computer has <span class="qw">an AZERTY</span> Keyboard or something similar, consider removing Cameroon <span class="qw">QWERTY</span> and try the Cameroon <span class="qw">AZERTY</span> Keyboard</blockquote>
<!--Touch Keyboard-->
<h2 class="color">Touch Keyboard (Android, iOS)</h2>

<p xml:lang="en">The Cameroon keyboard has been adapted to use touch-based features when used on a touch device, such as an <span class="Android">Android</span> or <span class="iOS">iOS</span> phone or tablet. The following sections will explain the use of the touch features of the Cameroon Keyboard. If you plug in an external keyboard to your <span class="Android">Android</span> or <span class="iOS">iOS</span> device, the keyboard will respond to the keyboard as it would on a desktop or laptop computer. </p>
<h3 class="color" xml:lang="en">Keyboard Use</h3>
<p xml:lang="en">The Cameroon Keyboard works like most Android keyboards. Tap a key to type the displayed letter. Long-press a key marked with a dot to access hidden characters. </p>
<span class="qw">
<img src="longpress-qwerty.png" height="300" />
</span>
<h3 class="color" xml:lang="en">Special Keys</h3>
<p xml:lang="en">Or use a special key to access other characters.</p>
<span class="qw">
<img src="modkeys-en-q.png" height="300" xml:lang="en" />
</span>
<h3 class="color" xml:lang="en">Caps Lock</h3>
<p>Double tap quickly on the shift key to activate Caps Lock. All letters typed will be capital until the shift key is pressed again to deactivate Caps Lock.</p>
<div class="keyman">
<h3 class="color" xml:lang="en">Switching to Another Keyman Keyboard</h3>
<p xml:lang="en">To switch to another Keyman keyboard, for example <span class="qw">Cameroon AZERTY</span>, follow these steps: </p>
<ol>
<li xml:lang="en">With the keyboard visible, touch the globe key:  <br />
<img src="globe.png" />
<br />This will bring up a list of all currently installed languages.<br />If you have already downloaded additional languages, they will appear here. Simply select them and the keyboard will reappear with the new language. 
</li>
</ol>
<p xml:lang="en">If you have not yet installed other keyboards, click the + button in the top-right corner of your screen.</p>
<ol>
<li xml:lang="en">A list of all available languages will appear. Scroll through this list until you find the language you want to install. Some languages may have multiple keyboards - for example we have 10+ different Tamil keyboards.  Select the language and keyboard you want to install - a popup will ask for confirmation, hit the Download button. </li>
<li xml:lang="en">Once the download is complete, the new keyboard will be selected. Touch the Return button on the top left corner of the popup and the new keyboard will become active. 
</li>
</ol>
<blockquote xml:lang="en">Note: If you are more familiar with a<span class="qw">n AZERTY</span> keyboard layout, consider switching to the Cameroon <span class="qw">AZERTY</span> Keyboard.</blockquote>
</div>
<h3 class="color" xml:lang="en">Switching to Other <span class="keyman">Non-Keyman</span> Keyboards</h3>
<p xml:lang="en">You can switch between several keyboards. On most phones, the process is:</p>
<ol>
<li xml:lang="en">Tap in a text area to make sure the keyboard is showing.</li>
<li xml:lang="en">Swipe from the top of the screen down to the bottom.</li>
<li xml:lang="en">Choose the button 'Select Keyboard'.</li>
<li xml:lang="en">Choose the desired keyboard.</li>
</ol>
<h3 class="color" xml:lang="en">Physical Keyboards</h3>
<p xml:lang="en">If you choose to connect a physical keyboard (i.e. through Bluetooth or USB) to your mobile device, the physical keyboard will respond like a desktop keyboard. See the Physical Keyboard Section of this document for instructions and combinations.</p>
<blockquote xml:lang="en">Note: If your physical keyboard uses an <span class="qw">AZERTY (French)</span> keyboard layout, consider switching to the Cameroon <span class="qw">AZERTY</span> Keyboard.
</blockquote>
</div>
<hr style="clear:both;" />
<p xml:lang="en">This keyboard defines some keys that are set by default as "hotkeys" when Keyman is installed. To use this keyboard, you will want to go to <b>Configuration.../Hotkeys</b>, select the hotkey name, and either change the hotkey or turn it off.
<br />Currently,
</p>
<ul xml:lang="en">
<li>"Switch Keyman Desktop Off" uses Shift+Alt+O</li>
<li>"Open Keyboard Menu" uses Shift+Alt+M</li>
<li>"Show On Screen Keyboard Pane" uses Shift+Alt+K</li>
</ul>
<p xml:lang="en">The Cameroon Keyboard is developed by SIL Cameroon. For more information about the Cameroon Keyboard or Language Technology in Cameroon, see <a href="https://langtechcameroon.info">https://langtechcameroon.info</a>
</p>
<p xml:lang="en" style="text-align: center; font-style: italic;">Copyright 2018-2022 SIL Cameroon</p>

</div>
<!--Ending English-->
<!--Starting French-->
<div id="fr" class="tab-content">
<a class="buttonlang warning marching-ants marching" href="#en">Click here to view this page in English...</a>
<div id="container">
<img src="ic_launcher.png" class="left" height="75" />
<img class="right" src="sil-logo-blue.png" height="75" />
<h1 class="color" xml:lang="fr">Clavier Cameroun <span class="qw">QWERTY</span>
<span class="keyman"> pour Keyman</span>
<br />par SIL Cameroon
</h1>
<p class="tagline" xml:lang="fr">Vous permettant de saisir du texte dans votre langue maternelle !</p>
<p xml:lang="fr">Bienvenue au Clavier camerounais <span class="qw">QWERTY</span> pour Keyman. Cette page explique comment saisir du texte dans les langues vernaculaires du Cameroun à l'aide du clavier <span class="qw">QWERTY</span> du Cameroun.</p>
<p xml:lang="fr">Le clavier camerounais <span class="qw">QWERTY</span>, un des claviers virtuels maintenus par l'équipe de Technologie linguistique de <a href="https://silcam.org/">SIL Cameroun</a>, vous permet de saisir toutes les langues qui suivent <a href="https://langtechcameroon.info/gacl/">l'Alphabet général des langues camerounaises</a>. L'Ethnologue recense 279 langues vivantes au Cameroun, dont 275 sont autochtones. Pour une liste de ces langues, verrez <a href="https://www.ethnologue.com/country/CM/">Cameroun dans l'Ethnologue.</a>
</p>
<hr />
<p xml:lang="fr">Pour profiter des caractéristiques uniques de chaque appareil, le clavier camerounais <span class="qw">QWERTY</span> se comporte différemment sur les claviers physiques et les écrans tactiles, veuillez choisir votre interface ci-dessous :</p>
<!--Physical Keyboard-->
<h2 class="color" xml:lang="fr"">Clavier physique (Windows, Mac, Linux, aussi Android et iOS avec un clavier externe) </h2>
<p xml:lang="fr">Cette section explique comment utiliser le clavier Cameroun <span class="qw">QWERTY</span> avec des claviers physiques, exploitant la puissance de plusieurs doigts pour taper plus facilement.</p>
<h3 class="color" xml:lang="fr">Survol sur la disposition</h3>
<p xml:lang="fr">Voici la disposition du clavier Cameroun <span class="qw">QWERTY</span>. Une fois que vous avez appris à utiliser les touches <span class="keycap">CAM</span> et <span class="keycap">Shift</span>, cette image peut être utilisée comme référence rapide pour trouver les caractères disponibles.</p>
<img src="QwertyColor.png" class="full qw" />
<h3 class="color" xml:lang="fr">Comment faire les combinaisons de touche</h3>
<img class="center" src="e_tableau.png" xml:lang="fr" />
<p xml:lang="fr">Chaque touche du Clavier camerounais peut vous servir à produire des caractères (lettres) différents. </p>
<ol style="list-style-type:decimal; ">
<li xml:lang="fr">Si vous tapez la touche <span class="keycap">e</span> une fois, vous obtiendrez un « e » en minuscule. </li>
<li xml:lang="fr">Parfois, il faut utiliser deux touches sur le clavier pour obtenir la lettre souhaitée. La touche <span class="keycap">MAJ</span> (SHIFT) est une touche sur le clavier d’un ordinateur. Elle est utilisée pour saisir les lettres en majuscule (par exemple : « ABC ») au lieu de lettres en minuscule (« abc »). Si vous appuyez la touche <span class="keycap">Maj</span> et tapez la touche <span class="keycap">E</span> une fois, vous obtiendrez l'« E » en majuscule. </li>
<li xml:lang="fr">Le Clavier camerounais est spécial, et il est possible de saisir d’autres caractères non imprimés sur votre clavier à l’aide de la touche « CAM » (Cameroun). Sur votre Clavier Camerounais
<span class="qw">QWERTY</span>, la touche CAM est le <span class="qw">point-virgule</span> (<span class="keycap qw">;</span>). Chaque fois que vous avez besoin de la touche CAM, tapez la touche
<span class="keycap qw">;</span>. Pour obtenir les caractères spéciaux situés sur le côté droit de chaque touche dans la disposition du clavier (par exemple : « əɔɓ ») au lieu de caractères simples (comme « eob »), vous devez utiliser la touche CAM. Si vous tapez la touche <span class="keycap qw">;</span> une fois, puis tapez la touche <span class="keycap">E</span>, vous obtiendrez le schwa « ə ».
</li>
<li xml:lang="fr">Parfois, il faut utiliser trois touches pour obtenir le caractère souhaité. Si vous tapez la touche <span class="keycap qw">;</span> une fois, puis appuyez sur le <span class="keycap">Shift</span> en tapant le <span class="keycap">E</span>, vous obtiendrez le schwa en majuscule « Ə ».</li>
</ol>
<h3 class="color" xml:lang="fr">Combinaisons de touche spécifiques:</h3>
<p xml:lang="fr">Les ordinateurs achetés dans différents pays ont tendance à avoir des claviers physiques différents. Lorsque vous utilisez des claviers virtuels, il est BEAUCOUP plus facile d'apprendre le clavier si les touches sont à la même place que les lettres que vous voulez taper.</p>
<p xml:lang="fr">Le clavier Cameroun <span class="qw">QWERTY</span> est conçu pour les ordinateurs équipés des claviers physiques suivants :</p>
<ul xml:lang="fr" class="qw">
<li>Anglais États-Unis (QWERTY) : <a href="qwerty-us-fr.php">Voir toutes les combinaisons.</a></li>
<li>Anglais Royaume-Uni (QWERTY) : <a href="qwerty-uk-fr.php">Voir toutes les combinaisons.</a></li>
<li>Allemand (QWERTZ) : <a href="qwerty-de-fr.php">Voir toutes les combinaisons.</a></li>
<li>Suisse (QWERTZ) : <a href="qwerty-ch-fr.php">Voir toutes les combinaisons.</a></li>
</ul>
<blockquote xml:lang="fr">Note: Si votre ordinateur a un clavier <span class="qw"> AZERTY</span> ou quelque chose de similaires, envisagez de retirer le clavier Cameroun <span class="qw">QWERTY</span> et installez le clavier Cameroon <span class="qw">AZERTY</span>.</blockquote>
    
<h2 class="color">Clavier tactile (Android, iOS)</h2>
<p xml:lang="fr">Le Claver camerounais est spécialement adapté pour une utilisation sur les appareils tactiles comme un téléphone mobile ou une tablette <span class="Android">Android</span> ou <span class="iOS">iOS</span>. Vous pouvez utiliser le Clavier camerounais comme n'importe quel autre clavier virtuel. Il faut noter que si vous branchez ou connectez un clavier à l'appareil, le Clavier camerounais fonctionnera comme un claver sur un ordinateur desktop ou portable.</p>
<h3 class="color" xml:lang="fr">Mode d'emploi du clavier</h3>
<p xml:lang="fr">Le clavier camerounais fonctionne comme la plupart des claviers Android ou iOS. Tapez sur une touche pour saisir la lettre affichée. Appuyez longuement sur une touche marquée d'un point blanc pour accéder aux caractères cachés.</p>
<span class="qw">
<img src="longpress-qwerty.png" height="300" />
</span>
<h3 class="color" xml:lang="fr">Touches spéciales</h3>
<p xml:lang="fr">Ou utilisez une touche spéciale pour accéder à d'autres caractères !</p>
<span class="qw">
<img src="modkeys-fr-q.png" height="300" xml:lang="fr" />
</span>
<h3 class="color" xml:lang="en">Verrouillage des majuscules</h3>
<p>Double appui vite sur la touche shift pour activer le verrouillage des majuscules. Toutes les lettres tapées seront en majuscules jusqu'à ce que l'on appuie à nouveau sur la touche shift pour désactiver le verrouillage des majuscules.</p>
<div class="keyman">
<h3 class="color" xml:lang="fr">Changez vers un autre clavier Keyman</h3>
<ol>
<li xml:lang="fr">Le clavier étant visible, appuyez sur la touche globe : <br />
<img src="globe.png" />
<br />Une liste de toutes les langues actuellement installées s'affichera.<br />Si vous avez déjà téléchargé d'autres langues, elles apparaitront ici. Il suffit de les sélectionner et le clavier réapparaitra avec la nouvelle langue. 
</li>
</ol>
<p xml:lang="fr">Si vous n'avez pas encore installé de langues, appuyez sur le bouton + dans le coin supérieur droit de votre écran.</p>
<ol>
<li xml:lang="fr">Une liste de toutes les langues disponibles apparaitra. Faites défiler cette liste jusqu'à ce que vous trouviez la langue que vous souhaitez installer. Certaines langues peuvent avoir plusieurs claviers - par exemple, nous avons plus de 10 claviers tamouls différents.  Sélectionnez la langue et le clavier que vous voulez installer - un popup vous demandera confirmation, cliquez sur le bouton Télécharger.</li>
<li xml:lang="fr"> Une fois le téléchargement terminé, le nouveau clavier sera sélectionné. Appuyez sur le bouton Retour dans le coin supérieur gauche de la fenêtre contextuelle et le nouveau clavier deviendra actif.</li>
</ol>
<blockquote xml:lang="fr">Note : Si vous êtes plus familier avec la disposition d'un clavier <span class="qw">AZERTY</span>, pensez à passer au clavier Cameroun <span class="qw">AZERTY</span>.
</blockquote>
</div>
<h3 class="color" xml:lang="fr">Basculer entre différents claviers <span class="keyman">non-Keyman</span>
</h3>
<p xml:lang="fr">Vous pouvez basculer entre différents claviers. Dans la plupart des téléphones, le processus est le suivant:</p>
<ol>
<li xml:lang="fr">Cliquez dans une zone de texte pour faire afficher le clavier.</li>
<li xml:lang="fr">Faites glisser le doigt du haut vers le bas.</li>
<li xml:lang="fr">Choisissez le bouton 'Sélectionner un clavier'.</li>
<li xml:lang="fr">Sélectionnez le clavier désiré.</li>
</ol>
<h3 class="color" xml:lang="fr">Claviers physiques</h3>
<p xml:lang="fr">Si vous choisissez de connecter un clavier physique (c'est-à-dire via Bluetooth ou USB) à votre appareil mobile, le clavier physique répondra comme un clavier de bureau. Voir la section Clavier physique de ce document pour les instructions et les combinaisons.</p>
<blockquote xml:lang="fr">Note : Si vous êtes plus familier avec la disposition d'un clavier <span class="qw">AZERTY</span>, pensez à passer au clavier Cameroun <span class="qw">AZERTY</span>.
</blockquote>
<hr style="clear:both;" />
<p xml:lang="fr">Ce clavier définit certaines touches qui sont définies par défaut comme "hotkeys" lorsque Keyman est installé. Pour utiliser ce clavier, il faut aller dans <b>Configuration.../Hotkeys</b>, sélectionnez le nom de la touche de raccourci et modifiez la touche de raccourci ou désactivez-la.
<br />Actuellement,
</p>
<ul xml:lang="fr">
<li>"Switch Keyman Desktop Off" utilise Shift+Alt+O</li>
<li>"Ouvrir le menu du clavier" utilise Maj+Alt+M</li>
<li>"Show On Screen Keyboard Pane" utilise Shift+Alt+K</li>
</ul>
<p xml:lang="fr">Le Clavier Camerounais est un produit de SIL Cameroun. Pour plus d´infos sur le Claver Camerounais ou la technologie linguistique au Cameroun, veuillez visiter <a href="https://langtechcameroon.info">https://langtechcameroon.info</a>
</p>
<p xml:lang="fr" style="text-align: center;  font-style: italic;">Copyright 2018-2022 SIL Cameroun</p>
</div>
</div>
<!--Ending French-->
</div>
<!-- ks:generated:start -->
<h2>Typing Guide</h2><table><thead><tr><th>Character</th><th>Name</th><th>Keys</th></tr></thead><tbody><tr><td> </td><td>U+00A0 NO-BREAK SPACE</td><td><kbd>Ctrl + Space</kbd></td></tr><tr><td>©</td><td>U+00A9 COPYRIGHT SIGN</td><td><kbd>Shift+AltGr + c</kbd></td></tr><tr><td>«</td><td>U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK</td><td><kbd>Shift+AltGr + ,</kbd></td></tr><tr><td>®</td><td>U+00AE REGISTERED SIGN</td><td><kbd>Shift+AltGr + r</kbd></td></tr><tr><td>±</td><td>U+00B1 PLUS-MINUS SIGN</td><td><kbd>Shift+AltGr + =</kbd></td></tr><tr><td>¸</td><td>U+00B8 CEDILLA</td><td><kbd>=</kbd> then <kbd>◌̧</kbd></td></tr><tr><td>»</td><td>U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK</td><td><kbd>Shift+AltGr + .</kbd></td></tr><tr><td>¼</td><td>U+00BC VULGAR FRACTION ONE QUARTER</td><td><kbd>AltGr + 1</kbd></td></tr><tr><td>½</td><td>U+00BD VULGAR FRACTION ONE HALF</td><td><kbd>AltGr + 2</kbd></td></tr><tr><td>¾</td><td>U+00BE VULGAR FRACTION THREE QUARTERS</td><td><kbd>AltGr + 3</kbd></td></tr><tr><td>Â</td><td>U+00C2 LATIN CAPITAL LETTER A WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>Æ</td><td>U+00C6 LATIN CAPITAL LETTER AE</td><td><kbd>Shift+AltGr + f</kbd></td></tr><tr><td>Ç</td><td>U+00C7 LATIN CAPITAL LETTER C WITH CEDILLA</td><td>See the layout pictures</td></tr><tr><td>Ê</td><td>U+00CA LATIN CAPITAL LETTER E WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>Ô</td><td>U+00D4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>×</td><td>U+00D7 MULTIPLICATION SIGN</td><td><kbd>Shift+AltGr + 8</kbd></td></tr><tr><td>Ø</td><td>U+00D8 LATIN CAPITAL LETTER O WITH STROKE</td><td><kbd>Shift+AltGr + p</kbd></td></tr><tr><td>â</td><td>U+00E2 LATIN SMALL LETTER A WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>æ</td><td>U+00E6 LATIN SMALL LETTER AE</td><td><kbd>AltGr + f</kbd></td></tr><tr><td>ç</td><td>U+00E7 LATIN SMALL LETTER C WITH CEDILLA</td><td>See the layout pictures</td></tr><tr><td>ê</td><td>U+00EA LATIN SMALL LETTER E WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>ô</td><td>U+00F4 LATIN SMALL LETTER O WITH CIRCUMFLEX</td><td>See the layout pictures</td></tr><tr><td>÷</td><td>U+00F7 DIVISION SIGN</td><td><kbd>AltGr + /</kbd></td></tr><tr><td>ø</td><td>U+00F8 LATIN SMALL LETTER O WITH STROKE</td><td><kbd>AltGr + p</kbd></td></tr><tr><td>Ŋ</td><td>U+014A LATIN CAPITAL LETTER ENG</td><td><kbd>Shift+AltGr + n</kbd></td></tr><tr><td>ŋ</td><td>U+014B LATIN SMALL LETTER ENG</td><td><kbd>AltGr + n</kbd></td></tr><tr><td>Œ</td><td>U+0152 LATIN CAPITAL LIGATURE OE</td><td><kbd>Shift+AltGr + t</kbd></td></tr><tr><td>œ</td><td>U+0153 LATIN SMALL LIGATURE OE</td><td><kbd>AltGr + t</kbd></td></tr><tr><td>Ū</td><td>U+016A LATIN CAPITAL LETTER U WITH MACRON</td><td>See the layout pictures</td></tr><tr><td>ū</td><td>U+016B LATIN SMALL LETTER U WITH MACRON</td><td>See the layout pictures</td></tr><tr><td>Ɓ</td><td>U+0181 LATIN CAPITAL LETTER B WITH HOOK</td><td><kbd>Shift+AltGr + b</kbd></td></tr><tr><td>Ɔ</td><td>U+0186 LATIN CAPITAL LETTER OPEN O</td><td><kbd>Shift+AltGr + o</kbd></td></tr><tr><td>Ɗ</td><td>U+018A LATIN CAPITAL LETTER D WITH HOOK</td><td><kbd>Shift+AltGr + d</kbd></td></tr><tr><td>Ə</td><td>U+018F LATIN CAPITAL LETTER SCHWA</td><td><kbd>Shift+AltGr + e</kbd></td></tr><tr><td>Ɛ</td><td>U+0190 LATIN CAPITAL LETTER OPEN E</td><td><kbd>Shift+AltGr + a</kbd></td></tr><tr><td>Ɨ</td><td>U+0197 LATIN CAPITAL LETTER I WITH STROKE</td><td><kbd>Shift+AltGr + i</kbd></td></tr><tr><td>Ƴ</td><td>U+01B3 LATIN CAPITAL LETTER Y WITH HOOK</td><td><kbd>Shift+AltGr + y</kbd></td></tr><tr><td>ƴ</td><td>U+01B4 LATIN SMALL LETTER Y WITH HOOK</td><td><kbd>AltGr + y</kbd></td></tr><tr><td>Ʉ</td><td>U+0244 LATIN CAPITAL LETTER U BAR</td><td><kbd>Shift+AltGr + u</kbd></td></tr><tr><td>ɓ</td><td>U+0253 LATIN SMALL LETTER B WITH HOOK</td><td><kbd>AltGr + b</kbd></td></tr><tr><td>ɔ</td><td>U+0254 LATIN SMALL LETTER OPEN O</td><td><kbd>AltGr + o</kbd></td></tr><tr><td>ɗ</td><td>U+0257 LATIN SMALL LETTER D WITH HOOK</td><td><kbd>AltGr + d</kbd></td></tr><tr><td>ə</td><td>U+0259 LATIN SMALL LETTER SCHWA</td><td><kbd>AltGr + e</kbd></td></tr><tr><td>ɛ</td><td>U+025B LATIN SMALL LETTER OPEN E</td><td><kbd>AltGr + a</kbd></td></tr><tr><td>ɨ</td><td>U+0268 LATIN SMALL LETTER I WITH STROKE</td><td><kbd>AltGr + i</kbd></td></tr><tr><td>ʉ</td><td>U+0289 LATIN SMALL LETTER U BAR</td><td><kbd>AltGr + u</kbd></td></tr><tr><td>ʼ</td><td>U+02BC MODIFIER LETTER APOSTROPHE</td><td><kbd>AltGr + g</kbd></td></tr><tr><td>ˆ</td><td>U+02C6 MODIFIER LETTER CIRCUMFLEX ACCENT</td><td><kbd>=</kbd> then <kbd>◌̂</kbd></td></tr><tr><td>ˇ</td><td>U+02C7 CARON</td><td><kbd>=</kbd> then <kbd>◌̌</kbd></td></tr><tr><td>ˈ</td><td>U+02C8 MODIFIER LETTER VERTICAL LINE</td><td><kbd>=</kbd> then <kbd>◌̍</kbd></td></tr><tr><td>ˉ</td><td>U+02C9 MODIFIER LETTER MACRON</td><td><kbd>=</kbd> then <kbd>◌̄</kbd></td></tr><tr><td>ˊ</td><td>U+02CA MODIFIER LETTER ACUTE ACCENT</td><td><kbd>=</kbd> then <kbd>◌́</kbd></td></tr><tr><td>ˋ</td><td>U+02CB MODIFIER LETTER GRAVE ACCENT</td><td><kbd>=</kbd> then <kbd>◌̀</kbd></td></tr><tr><td>◌̀</td><td>U+0300 COMBINING GRAVE ACCENT</td><td><kbd>&#39;</kbd></td></tr><tr><td>◌́</td><td>U+0301 COMBINING ACUTE ACCENT</td><td><kbd>[</kbd></td></tr><tr><td>◌̂</td><td>U+0302 COMBINING CIRCUMFLEX ACCENT</td><td><kbd>Shift + &#39;</kbd></td></tr><tr><td>◌̃</td><td>U+0303 COMBINING TILDE</td><td><kbd>Shift + `</kbd></td></tr><tr><td>◌̄</td><td>U+0304 COMBINING MACRON</td><td><kbd>AltGr + -</kbd></td></tr><tr><td>◌̈</td><td>U+0308 COMBINING DIAERESIS</td><td><kbd>Shift + ]</kbd></td></tr><tr><td>◌̌</td><td>U+030C COMBINING CARON</td><td><kbd>Shift + [</kbd></td></tr><tr><td>◌̍</td><td>U+030D COMBINING VERTICAL LINE ABOVE</td><td><kbd>`</kbd></td></tr><tr><td>◌̣</td><td>U+0323 COMBINING DOT BELOW</td><td><kbd>Shift+AltGr + j</kbd></td></tr><tr><td>◌̧</td><td>U+0327 COMBINING CEDILLA</td><td><kbd>AltGr + c</kbd></td></tr><tr><td>◌̰</td><td>U+0330 COMBINING TILDE BELOW</td><td><kbd>AltGr + j</kbd></td></tr><tr><td>Α</td><td>U+0391 GREEK CAPITAL LETTER ALPHA</td><td>See the layout pictures</td></tr><tr><td>α</td><td>U+03B1 GREEK SMALL LETTER ALPHA</td><td><kbd>AltGr + h</kbd></td></tr><tr><td>◌᷄</td><td>U+1DC4 COMBINING MACRON-ACUTE</td><td><kbd>Shift+AltGr + l</kbd></td></tr><tr><td>◌᷅</td><td>U+1DC5 COMBINING GRAVE-MACRON</td><td><kbd>AltGr + k</kbd></td></tr><tr><td>◌᷆</td><td>U+1DC6 COMBINING MACRON-GRAVE</td><td><kbd>AltGr + l</kbd></td></tr><tr><td>◌᷇</td><td>U+1DC7 COMBINING ACUTE-MACRON</td><td><kbd>Shift+AltGr + k</kbd></td></tr><tr><td>Ḷ</td><td>U+1E36 LATIN CAPITAL LETTER L WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>ḷ</td><td>U+1E37 LATIN SMALL LETTER L WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>Ṛ</td><td>U+1E5A LATIN CAPITAL LETTER R WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>ṛ</td><td>U+1E5B LATIN SMALL LETTER R WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>Ẅ</td><td>U+1E84 LATIN CAPITAL LETTER W WITH DIAERESIS</td><td><kbd>Shift+AltGr + w</kbd></td></tr><tr><td>ẅ</td><td>U+1E85 LATIN SMALL LETTER W WITH DIAERESIS</td><td><kbd>AltGr + w</kbd></td></tr><tr><td>Ạ</td><td>U+1EA0 LATIN CAPITAL LETTER A WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>ạ</td><td>U+1EA1 LATIN SMALL LETTER A WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>Ẹ</td><td>U+1EB8 LATIN CAPITAL LETTER E WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>ẹ</td><td>U+1EB9 LATIN SMALL LETTER E WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>Ọ</td><td>U+1ECC LATIN CAPITAL LETTER O WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>ọ</td><td>U+1ECD LATIN SMALL LETTER O WITH DOT BELOW</td><td>See the layout pictures</td></tr><tr><td>–</td><td>U+2013 EN DASH</td><td><kbd>Shift+AltGr + q</kbd></td></tr><tr><td>—</td><td>U+2014 EM DASH</td><td><kbd>AltGr + q</kbd></td></tr><tr><td>‘</td><td>U+2018 LEFT SINGLE QUOTATION MARK</td><td><kbd>AltGr + 9</kbd></td></tr><tr><td>’</td><td>U+2019 RIGHT SINGLE QUOTATION MARK</td><td><kbd>AltGr + 0</kbd></td></tr><tr><td>“</td><td>U+201C LEFT DOUBLE QUOTATION MARK</td><td><kbd>Shift+AltGr + 9</kbd></td></tr><tr><td>”</td><td>U+201D RIGHT DOUBLE QUOTATION MARK</td><td><kbd>Shift+AltGr + 0</kbd></td></tr><tr><td>†</td><td>U+2020 DAGGER</td><td><kbd>Shift+AltGr + z</kbd></td></tr><tr><td>…</td><td>U+2026 HORIZONTAL ELLIPSIS</td><td><kbd>AltGr + z</kbd></td></tr><tr><td>‹</td><td>U+2039 SINGLE LEFT-POINTING ANGLE QUOTATION MARK</td><td><kbd>AltGr + ,</kbd></td></tr><tr><td>›</td><td>U+203A SINGLE RIGHT-POINTING ANGLE QUOTATION MARK</td><td><kbd>AltGr + .</kbd></td></tr><tr><td>€</td><td>U+20AC EURO SIGN</td><td><kbd>Shift+AltGr + 4</kbd></td></tr><tr><td>™</td><td>U+2122 TRADE MARK SIGN</td><td><kbd>AltGr+Shift + m</kbd></td></tr><tr><td>◌</td><td>U+25CC DOTTED CIRCLE</td><td><kbd>AltGr + r</kbd></td></tr><tr><td>Ɑ</td><td>U+2C6D LATIN CAPITAL LETTER ALPHA</td><td><kbd>Shift+AltGr + h</kbd></td></tr><tr><td>Ꞌ</td><td>U+A78B LATIN CAPITAL LETTER SALTILLO</td><td><kbd>Shift+AltGr + g</kbd></td></tr><tr><td>ꞌ</td><td>U+A78C LATIN SMALL LETTER SALTILLO</td><td><kbd>AltGr + v</kbd></td></tr><tr><td>ﬀ</td><td>U+FB00 LATIN SMALL LIGATURE FF</td><td>See the layout pictures</td></tr></tbody></table>
<h2>How This Keyboard Works</h2><p>Some characters are typed in two steps. First press a dead key, which types nothing on its own, then press the letter. The typing guide lists each dead key sequence.</p><p>Some characters are on a second layer reached with the right Alt key (AltGr). Hold right Alt and press the key shown in the typing guide.</p><p>Accents and other marks are typed after the letter they belong to. Type the base letter first, then the mark.</p>
<h2>Characters on This Keyboard</h2><h3>Letters</h3><ul><li>A U+0041 LATIN CAPITAL LETTER A</li><li>B U+0042 LATIN CAPITAL LETTER B</li><li>C U+0043 LATIN CAPITAL LETTER C</li><li>D U+0044 LATIN CAPITAL LETTER D</li><li>E U+0045 LATIN CAPITAL LETTER E</li><li>F U+0046 LATIN CAPITAL LETTER F</li><li>G U+0047 LATIN CAPITAL LETTER G</li><li>H U+0048 LATIN CAPITAL LETTER H</li><li>I U+0049 LATIN CAPITAL LETTER I</li><li>J U+004A LATIN CAPITAL LETTER J</li><li>K U+004B LATIN CAPITAL LETTER K</li><li>L U+004C LATIN CAPITAL LETTER L</li><li>M U+004D LATIN CAPITAL LETTER M</li><li>N U+004E LATIN CAPITAL LETTER N</li><li>O U+004F LATIN CAPITAL LETTER O</li><li>P U+0050 LATIN CAPITAL LETTER P</li><li>Q U+0051 LATIN CAPITAL LETTER Q</li><li>R U+0052 LATIN CAPITAL LETTER R</li><li>S U+0053 LATIN CAPITAL LETTER S</li><li>T U+0054 LATIN CAPITAL LETTER T</li><li>U U+0055 LATIN CAPITAL LETTER U</li><li>V U+0056 LATIN CAPITAL LETTER V</li><li>W U+0057 LATIN CAPITAL LETTER W</li><li>X U+0058 LATIN CAPITAL LETTER X</li><li>Y U+0059 LATIN CAPITAL LETTER Y</li><li>Z U+005A LATIN CAPITAL LETTER Z</li><li>a U+0061 LATIN SMALL LETTER A</li><li>b U+0062 LATIN SMALL LETTER B</li><li>c U+0063 LATIN SMALL LETTER C</li><li>d U+0064 LATIN SMALL LETTER D</li><li>e U+0065 LATIN SMALL LETTER E</li><li>f U+0066 LATIN SMALL LETTER F</li><li>g U+0067 LATIN SMALL LETTER G</li><li>h U+0068 LATIN SMALL LETTER H</li><li>i U+0069 LATIN SMALL LETTER I</li><li>j U+006A LATIN SMALL LETTER J</li><li>k U+006B LATIN SMALL LETTER K</li><li>l U+006C LATIN SMALL LETTER L</li><li>m U+006D LATIN SMALL LETTER M</li><li>n U+006E LATIN SMALL LETTER N</li><li>o U+006F LATIN SMALL LETTER O</li><li>p U+0070 LATIN SMALL LETTER P</li><li>q U+0071 LATIN SMALL LETTER Q</li><li>r U+0072 LATIN SMALL LETTER R</li><li>s U+0073 LATIN SMALL LETTER S</li><li>t U+0074 LATIN SMALL LETTER T</li><li>u U+0075 LATIN SMALL LETTER U</li><li>v U+0076 LATIN SMALL LETTER V</li><li>w U+0077 LATIN SMALL LETTER W</li><li>x U+0078 LATIN SMALL LETTER X</li><li>y U+0079 LATIN SMALL LETTER Y</li><li>z U+007A LATIN SMALL LETTER Z</li><li>Â U+00C2 LATIN CAPITAL LETTER A WITH CIRCUMFLEX</li><li>Æ U+00C6 LATIN CAPITAL LETTER AE</li><li>Ç U+00C7 LATIN CAPITAL LETTER C WITH CEDILLA</li><li>Ê U+00CA LATIN CAPITAL LETTER E WITH CIRCUMFLEX</li><li>Ô U+00D4 LATIN CAPITAL LETTER O WITH CIRCUMFLEX</li><li>Ø U+00D8 LATIN CAPITAL LETTER O WITH STROKE</li><li>â U+00E2 LATIN SMALL LETTER A WITH CIRCUMFLEX</li><li>æ U+00E6 LATIN SMALL LETTER AE</li><li>ç U+00E7 LATIN SMALL LETTER C WITH CEDILLA</li><li>ê U+00EA LATIN SMALL LETTER E WITH CIRCUMFLEX</li><li>ô U+00F4 LATIN SMALL LETTER O WITH CIRCUMFLEX</li><li>ø U+00F8 LATIN SMALL LETTER O WITH STROKE</li><li>Ŋ U+014A LATIN CAPITAL LETTER ENG</li><li>ŋ U+014B LATIN SMALL LETTER ENG</li><li>Œ U+0152 LATIN CAPITAL LIGATURE OE</li><li>œ U+0153 LATIN SMALL LIGATURE OE</li><li>Ū U+016A LATIN CAPITAL LETTER U WITH MACRON</li><li>ū U+016B LATIN SMALL LETTER U WITH MACRON</li><li>Ɓ U+0181 LATIN CAPITAL LETTER B WITH HOOK</li><li>Ɔ U+0186 LATIN CAPITAL LETTER OPEN O</li><li>Ɗ U+018A LATIN CAPITAL LETTER D WITH HOOK</li><li>Ə U+018F LATIN CAPITAL LETTER SCHWA</li><li>Ɛ U+0190 LATIN CAPITAL LETTER OPEN E</li><li>Ɨ U+0197 LATIN CAPITAL LETTER I WITH STROKE</li><li>Ƴ U+01B3 LATIN CAPITAL LETTER Y WITH HOOK</li><li>ƴ U+01B4 LATIN SMALL LETTER Y WITH HOOK</li><li>Ʉ U+0244 LATIN CAPITAL LETTER U BAR</li><li>ɓ U+0253 LATIN SMALL LETTER B WITH HOOK</li><li>ɔ U+0254 LATIN SMALL LETTER OPEN O</li><li>ɗ U+0257 LATIN SMALL LETTER D WITH HOOK</li><li>ə U+0259 LATIN SMALL LETTER SCHWA</li><li>ɛ U+025B LATIN SMALL LETTER OPEN E</li><li>ɨ U+0268 LATIN SMALL LETTER I WITH STROKE</li><li>ʉ U+0289 LATIN SMALL LETTER U BAR</li><li>ʼ U+02BC MODIFIER LETTER APOSTROPHE</li><li>ˆ U+02C6 MODIFIER LETTER CIRCUMFLEX ACCENT</li><li>ˇ U+02C7 CARON</li><li>ˈ U+02C8 MODIFIER LETTER VERTICAL LINE</li><li>ˉ U+02C9 MODIFIER LETTER MACRON</li><li>ˊ U+02CA MODIFIER LETTER ACUTE ACCENT</li><li>ˋ U+02CB MODIFIER LETTER GRAVE ACCENT</li><li>Α U+0391 GREEK CAPITAL LETTER ALPHA</li><li>α U+03B1 GREEK SMALL LETTER ALPHA</li><li>Ḷ U+1E36 LATIN CAPITAL LETTER L WITH DOT BELOW</li><li>ḷ U+1E37 LATIN SMALL LETTER L WITH DOT BELOW</li><li>Ṛ U+1E5A LATIN CAPITAL LETTER R WITH DOT BELOW</li><li>ṛ U+1E5B LATIN SMALL LETTER R WITH DOT BELOW</li><li>Ẅ U+1E84 LATIN CAPITAL LETTER W WITH DIAERESIS</li><li>ẅ U+1E85 LATIN SMALL LETTER W WITH DIAERESIS</li><li>Ạ U+1EA0 LATIN CAPITAL LETTER A WITH DOT BELOW</li><li>ạ U+1EA1 LATIN SMALL LETTER A WITH DOT BELOW</li><li>Ẹ U+1EB8 LATIN CAPITAL LETTER E WITH DOT BELOW</li><li>ẹ U+1EB9 LATIN SMALL LETTER E WITH DOT BELOW</li><li>Ọ U+1ECC LATIN CAPITAL LETTER O WITH DOT BELOW</li><li>ọ U+1ECD LATIN SMALL LETTER O WITH DOT BELOW</li><li>Ɑ U+2C6D LATIN CAPITAL LETTER ALPHA</li><li>Ꞌ U+A78B LATIN CAPITAL LETTER SALTILLO</li><li>ꞌ U+A78C LATIN SMALL LETTER SALTILLO</li><li>ﬀ U+FB00 LATIN SMALL LIGATURE FF</li></ul><h3>Marks</h3><ul><li>◌̀ U+0300 COMBINING GRAVE ACCENT</li><li>◌́ U+0301 COMBINING ACUTE ACCENT</li><li>◌̂ U+0302 COMBINING CIRCUMFLEX ACCENT</li><li>◌̃ U+0303 COMBINING TILDE</li><li>◌̄ U+0304 COMBINING MACRON</li><li>◌̈ U+0308 COMBINING DIAERESIS</li><li>◌̌ U+030C COMBINING CARON</li><li>◌̍ U+030D COMBINING VERTICAL LINE ABOVE</li><li>◌̣ U+0323 COMBINING DOT BELOW</li><li>◌̧ U+0327 COMBINING CEDILLA</li><li>◌̰ U+0330 COMBINING TILDE BELOW</li><li>◌᷄ U+1DC4 COMBINING MACRON-ACUTE</li><li>◌᷅ U+1DC5 COMBINING GRAVE-MACRON</li><li>◌᷆ U+1DC6 COMBINING MACRON-GRAVE</li><li>◌᷇ U+1DC7 COMBINING ACUTE-MACRON</li></ul><h3>Punctuation and symbols</h3><ul><li>! U+0021 EXCLAMATION MARK</li><li>&quot; U+0022 QUOTATION MARK</li><li># U+0023 NUMBER SIGN</li><li>$ U+0024 DOLLAR SIGN</li><li>% U+0025 PERCENT SIGN</li><li>&amp; U+0026 AMPERSAND</li><li>&#39; U+0027 APOSTROPHE</li><li>( U+0028 LEFT PARENTHESIS</li><li>) U+0029 RIGHT PARENTHESIS</li><li>* U+002A ASTERISK</li><li>+ U+002B PLUS SIGN</li><li>, U+002C COMMA</li><li>- U+002D HYPHEN-MINUS</li><li>. U+002E FULL STOP</li><li>/ U+002F SOLIDUS</li><li>: U+003A COLON</li><li>; U+003B SEMICOLON</li><li>&lt; U+003C LESS-THAN SIGN</li><li>= U+003D EQUALS SIGN</li><li>&gt; U+003E GREATER-THAN SIGN</li><li>? U+003F QUESTION MARK</li><li>@ U+0040 COMMERCIAL AT</li><li>[ U+005B LEFT SQUARE BRACKET</li><li>\ U+005C REVERSE SOLIDUS</li><li>] U+005D RIGHT SQUARE BRACKET</li><li>^ U+005E CIRCUMFLEX ACCENT</li><li>_ U+005F LOW LINE</li><li>` U+0060 GRAVE ACCENT</li><li>{ U+007B LEFT CURLY BRACKET</li><li>| U+007C VERTICAL LINE</li><li>} U+007D RIGHT CURLY BRACKET</li><li>~ U+007E TILDE</li><li>© U+00A9 COPYRIGHT SIGN</li><li>« U+00AB LEFT-POINTING DOUBLE ANGLE QUOTATION MARK</li><li>® U+00AE REGISTERED SIGN</li><li>± U+00B1 PLUS-MINUS SIGN</li><li>¸ U+00B8 CEDILLA</li><li>» U+00BB RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK</li><li>× U+00D7 MULTIPLICATION SIGN</li><li>÷ U+00F7 DIVISION SIGN</li><li>– U+2013 EN DASH</li><li>— U+2014 EM DASH</li><li>‘ U+2018 LEFT SINGLE QUOTATION MARK</li><li>’ U+2019 RIGHT SINGLE QUOTATION MARK</li><li>“ U+201C LEFT DOUBLE QUOTATION MARK</li><li>” U+201D RIGHT DOUBLE QUOTATION MARK</li><li>† U+2020 DAGGER</li><li>… U+2026 HORIZONTAL ELLIPSIS</li><li>‹ U+2039 SINGLE LEFT-POINTING ANGLE QUOTATION MARK</li><li>› U+203A SINGLE RIGHT-POINTING ANGLE QUOTATION MARK</li><li>€ U+20AC EURO SIGN</li><li>™ U+2122 TRADE MARK SIGN</li><li>◌ U+25CC DOTTED CIRCLE</li></ul><h3>Digits</h3><ul><li>0 U+0030 DIGIT ZERO</li><li>1 U+0031 DIGIT ONE</li><li>2 U+0032 DIGIT TWO</li><li>3 U+0033 DIGIT THREE</li><li>4 U+0034 DIGIT FOUR</li><li>5 U+0035 DIGIT FIVE</li><li>6 U+0036 DIGIT SIX</li><li>7 U+0037 DIGIT SEVEN</li><li>8 U+0038 DIGIT EIGHT</li><li>9 U+0039 DIGIT NINE</li><li>¼ U+00BC VULGAR FRACTION ONE QUARTER</li><li>½ U+00BD VULGAR FRACTION ONE HALF</li><li>¾ U+00BE VULGAR FRACTION THREE QUARTERS</li></ul><h3>Other</h3><ul><li>  U+00A0 NO-BREAK SPACE</li></ul>
<!-- ks:generated:end -->
</body>
