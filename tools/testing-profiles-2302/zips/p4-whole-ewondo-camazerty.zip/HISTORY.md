## 1.0 (2026-10-20)
* Created from sil_cameroon_azerty v6.1.2 via keyboard-studio.
* Initial release.
