## 1.0 (2026-10-20)
* Created from basic_kbdfr v1.1 via keyboard-studio.
* Initial release.
