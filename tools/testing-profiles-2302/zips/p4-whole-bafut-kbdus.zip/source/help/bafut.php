<?php 
  $pagename = 'US Basic Keyboard Help';
  $pagetitle = 'US Basic Keyboard Help';
  // Header we will tidy up later  
  require_once('header.php');


?>


<p style='margin: 16px 0 0 0'>
This keyboard is designed for the English language. It will also be useful for other languages that do not require special characters.
</p>

<h2>Desktop Keyboard Layout</h2>
<div id='osk' data-states='default shift'>
</div>

<h2>Tablet Keyboard Layout</h2>
<div id='osk-tablet' data-states='default shift'>
</div>

<h2>Phone Keyboard Layout</h2>
<p>Due to the size and number of keys, some characters are hidden in the long press. 
	Press and hold on the key with a little dot on the top right to reveal and use them.</p>
<div id='osk-phone' data-states='default shift numeric symbol currency'>
</div>

<!-- ks:generated:start -->
<h2>Typing Guide</h2><table><thead><tr><th>Character</th><th>Name</th><th>Keys</th></tr></thead><tbody><tr><td>Ŋ</td><td>U+014A LATIN CAPITAL LETTER ENG</td><td>See the layout pictures</td></tr><tr><td>ŋ</td><td>U+014B LATIN SMALL LETTER ENG</td><td>See the layout pictures</td></tr><tr><td>Ɔ</td><td>U+0186 LATIN CAPITAL LETTER OPEN O</td><td>See the layout pictures</td></tr><tr><td>Ə</td><td>U+018F LATIN CAPITAL LETTER SCHWA</td><td>See the layout pictures</td></tr><tr><td>Ɛ</td><td>U+0190 LATIN CAPITAL LETTER OPEN E</td><td>See the layout pictures</td></tr><tr><td>Ɨ</td><td>U+0197 LATIN CAPITAL LETTER I WITH STROKE</td><td>See the layout pictures</td></tr><tr><td>ɔ</td><td>U+0254 LATIN SMALL LETTER OPEN O</td><td>See the layout pictures</td></tr><tr><td>ə</td><td>U+0259 LATIN SMALL LETTER SCHWA</td><td>See the layout pictures</td></tr><tr><td>ɛ</td><td>U+025B LATIN SMALL LETTER OPEN E</td><td>See the layout pictures</td></tr><tr><td>ɨ</td><td>U+0268 LATIN SMALL LETTER I WITH STROKE</td><td>See the layout pictures</td></tr><tr><td>Ꞌ</td><td>U+A78B LATIN CAPITAL LETTER SALTILLO</td><td>See the layout pictures</td></tr><tr><td>ꞌ</td><td>U+A78C LATIN SMALL LETTER SALTILLO</td><td>See the layout pictures</td></tr></tbody></table>
<h2>Characters on This Keyboard</h2><h3>Letters</h3><ul><li>A U+0041 LATIN CAPITAL LETTER A</li><li>B U+0042 LATIN CAPITAL LETTER B</li><li>C U+0043 LATIN CAPITAL LETTER C</li><li>D U+0044 LATIN CAPITAL LETTER D</li><li>E U+0045 LATIN CAPITAL LETTER E</li><li>F U+0046 LATIN CAPITAL LETTER F</li><li>G U+0047 LATIN CAPITAL LETTER G</li><li>H U+0048 LATIN CAPITAL LETTER H</li><li>I U+0049 LATIN CAPITAL LETTER I</li><li>J U+004A LATIN CAPITAL LETTER J</li><li>K U+004B LATIN CAPITAL LETTER K</li><li>L U+004C LATIN CAPITAL LETTER L</li><li>M U+004D LATIN CAPITAL LETTER M</li><li>N U+004E LATIN CAPITAL LETTER N</li><li>O U+004F LATIN CAPITAL LETTER O</li><li>P U+0050 LATIN CAPITAL LETTER P</li><li>Q U+0051 LATIN CAPITAL LETTER Q</li><li>R U+0052 LATIN CAPITAL LETTER R</li><li>S U+0053 LATIN CAPITAL LETTER S</li><li>T U+0054 LATIN CAPITAL LETTER T</li><li>U U+0055 LATIN CAPITAL LETTER U</li><li>V U+0056 LATIN CAPITAL LETTER V</li><li>W U+0057 LATIN CAPITAL LETTER W</li><li>X U+0058 LATIN CAPITAL LETTER X</li><li>Y U+0059 LATIN CAPITAL LETTER Y</li><li>Z U+005A LATIN CAPITAL LETTER Z</li><li>a U+0061 LATIN SMALL LETTER A</li><li>b U+0062 LATIN SMALL LETTER B</li><li>c U+0063 LATIN SMALL LETTER C</li><li>d U+0064 LATIN SMALL LETTER D</li><li>e U+0065 LATIN SMALL LETTER E</li><li>f U+0066 LATIN SMALL LETTER F</li><li>g U+0067 LATIN SMALL LETTER G</li><li>h U+0068 LATIN SMALL LETTER H</li><li>i U+0069 LATIN SMALL LETTER I</li><li>j U+006A LATIN SMALL LETTER J</li><li>k U+006B LATIN SMALL LETTER K</li><li>l U+006C LATIN SMALL LETTER L</li><li>m U+006D LATIN SMALL LETTER M</li><li>n U+006E LATIN SMALL LETTER N</li><li>o U+006F LATIN SMALL LETTER O</li><li>p U+0070 LATIN SMALL LETTER P</li><li>q U+0071 LATIN SMALL LETTER Q</li><li>r U+0072 LATIN SMALL LETTER R</li><li>s U+0073 LATIN SMALL LETTER S</li><li>t U+0074 LATIN SMALL LETTER T</li><li>u U+0075 LATIN SMALL LETTER U</li><li>v U+0076 LATIN SMALL LETTER V</li><li>w U+0077 LATIN SMALL LETTER W</li><li>x U+0078 LATIN SMALL LETTER X</li><li>y U+0079 LATIN SMALL LETTER Y</li><li>z U+007A LATIN SMALL LETTER Z</li><li>Ŋ U+014A LATIN CAPITAL LETTER ENG</li><li>ŋ U+014B LATIN SMALL LETTER ENG</li><li>Ɔ U+0186 LATIN CAPITAL LETTER OPEN O</li><li>Ə U+018F LATIN CAPITAL LETTER SCHWA</li><li>Ɛ U+0190 LATIN CAPITAL LETTER OPEN E</li><li>Ɨ U+0197 LATIN CAPITAL LETTER I WITH STROKE</li><li>ɔ U+0254 LATIN SMALL LETTER OPEN O</li><li>ə U+0259 LATIN SMALL LETTER SCHWA</li><li>ɛ U+025B LATIN SMALL LETTER OPEN E</li><li>ɨ U+0268 LATIN SMALL LETTER I WITH STROKE</li><li>Ꞌ U+A78B LATIN CAPITAL LETTER SALTILLO</li><li>ꞌ U+A78C LATIN SMALL LETTER SALTILLO</li></ul><h3>Punctuation and symbols</h3><ul><li>! U+0021 EXCLAMATION MARK</li><li>&quot; U+0022 QUOTATION MARK</li><li># U+0023 NUMBER SIGN</li><li>$ U+0024 DOLLAR SIGN</li><li>% U+0025 PERCENT SIGN</li><li>&amp; U+0026 AMPERSAND</li><li>&#39; U+0027 APOSTROPHE</li><li>( U+0028 LEFT PARENTHESIS</li><li>) U+0029 RIGHT PARENTHESIS</li><li>* U+002A ASTERISK</li><li>+ U+002B PLUS SIGN</li><li>, U+002C COMMA</li><li>- U+002D HYPHEN-MINUS</li><li>. U+002E FULL STOP</li><li>/ U+002F SOLIDUS</li><li>: U+003A COLON</li><li>; U+003B SEMICOLON</li><li>&lt; U+003C LESS-THAN SIGN</li><li>= U+003D EQUALS SIGN</li><li>&gt; U+003E GREATER-THAN SIGN</li><li>? U+003F QUESTION MARK</li><li>@ U+0040 COMMERCIAL AT</li><li>[ U+005B LEFT SQUARE BRACKET</li><li>\ U+005C REVERSE SOLIDUS</li><li>] U+005D RIGHT SQUARE BRACKET</li><li>^ U+005E CIRCUMFLEX ACCENT</li><li>_ U+005F LOW LINE</li><li>` U+0060 GRAVE ACCENT</li><li>{ U+007B LEFT CURLY BRACKET</li><li>| U+007C VERTICAL LINE</li><li>} U+007D RIGHT CURLY BRACKET</li><li>~ U+007E TILDE</li></ul><h3>Digits</h3><ul><li>0 U+0030 DIGIT ZERO</li><li>1 U+0031 DIGIT ONE</li><li>2 U+0032 DIGIT TWO</li><li>3 U+0033 DIGIT THREE</li><li>4 U+0034 DIGIT FOUR</li><li>5 U+0035 DIGIT FIVE</li><li>6 U+0036 DIGIT SIX</li><li>7 U+0037 DIGIT SEVEN</li><li>8 U+0038 DIGIT EIGHT</li><li>9 U+0039 DIGIT NINE</li></ul>
<!-- ks:generated:end -->