# Bafut

## Links
- Online help: https://help.keyman.com/keyboard/bafut

## Supported Platforms
- any
