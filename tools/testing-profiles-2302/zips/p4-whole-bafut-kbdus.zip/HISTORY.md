## 1.0 (2026-10-20)
* Created from basic_kbdus v1.2 via keyboard-studio.
* Initial release.
